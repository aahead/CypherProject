document.getElementById("myButton").addEventListener('click', function(){ // Listening for submit button press
    let word = document.getElementById("wordInput").value; // grabbing basic values from html file
    let num = parseInt(document.getElementById("numInput").value);
    let direction = document.getElementById("dropDownInput").value;
    let encDec = document.getElementById("encDec").value;
    let output = document.getElementById("output");
    let newString = '' // this will be where the result shows up
    let wordList = 'abcdefghijklmnopqrstuvwxyz'; // alphabet to index through
    

    // this if statement decides which direction to index through the alphabet
    if(direction == 'left'){
        num = -num
        if (encDec == 'decrypt'){
            num = -num
        }
    } else {
        if (encDec == 'decrypt') {
            num = -num
        }
    }
    
// this loop iterates through the wordList variable to come up with the decryption or encryption
    for(let i = 0; i < word.length; i++) {
        let letter = word[i]

        if(!wordList.includes(letter)) { // checks if the alphabet has the letter from the input
            newString += letter
            continue
        } else {
            let index = wordList.indexOf(letter)
        

            if (num > 25 || num < -25) {
                num = parseInt(num % 26) 
            }

            index += num
            if(index > 25 || index < -25) {
                index = index % 26
            }        

            let newletter = wordList.at(index) // gets the new correctly decrypted/encrypted letter
            newString += newletter // appends that letter to the newString variable to get the final result
        }
    }
    
output.textContent = newString // outputs to the document

})